let s = {
  backgroundColor: "yellow",
};
function Footer() {
  return (
    <footer style={s}>
      <h3>End of website</h3>
      <button type="button">visit again</button>
    </footer>
  );
}
export default Footer;

// import { useState } from "react";
// import style from "./Products.module.css";
// // import car from "../assets/car-4.avif";
// function Products(props) {
//   const [count, setCount] = useState(0);
//   function Play() {
//     setCount(count + 1);
//   }
//   if (props.show == true) {
//     return (
//       <>
//         <div className={style.card}>
//           <img src={props.image} alt="car" />
//           <p>{props.name}</p>

//           <p>${props.price}</p>
//         </div>
//         <button onClick={Play}>{count == 10 ? `count:Infinity` : `count:${count}`}</button>
//       </>
//     );
//   } else {
//     return (
//       <>
//         <p>Out of stock.</p>
//       </>
//     );
//   }
// }
// export default Products;

function Navbar() {
  return (
    <nav>
      <h1>NextErchat</h1>
      <button>Login</button>
    </nav>
  );
}
export default Navbar;
